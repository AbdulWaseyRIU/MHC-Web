<footer class="footer">
        <div class="container">
            <div class="row">
                <div class="footer-col">
                    <h4>Maternity Health Care System</h4>
                    <p>Welcome to Maternity Health Care System</p>
                </div>
                <div class="footer-col">
                    <h4>Developed By</h4>
                    <ul>
                        <li><a href="#">Abdul Wasey Javed</a></li>
                        <li><a href="#">Hassan Ali Shoaib</a></li>
                        <li><a href="#">Moiz Sultan</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Quick Links</h4>
                    <ul>
                        <li><a href="#">Home</a></li>
                        <li><a href="#">About Our Software</a></li>
                        <li><a href="#">Scan</a></li>
                        <li><a href="#">Contact</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>
